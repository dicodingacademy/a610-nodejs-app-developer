function parseURL(url) {
  return new URL(url);
}
