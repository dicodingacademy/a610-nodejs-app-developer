# Instruksi: 02-2-breakpoint
> **Tugas**: Pada berkas `app.js`, tambahkan breakpoint pada baris kode awal setiap fungsi
`calculateAverage` dan `removeEvenNumbers`.

**Catatan:**
- Jangan ubah kode lain selain memberikan breakpoint.
- Pengubahan kode lain dapat menyebabkan pengujian gagal.
