# Instruksi: 02-1-inspect-mode
> **Tugas**: Pada berkas `answer.txt`, tulislah perintah dalam menjalankan berkas `app.js` dengan mengaktifkan mode inspect.

**Catatan:**
- Jangan hapus berkas apa pun yang ada di dalam folder ini.
- Jangan ubah kode di dalam berkas apa pun kecuali answer.txt.
