# Instruksi: 01-1-checking-syntax
Di folder 01-1-checking-syntax, terdapat berkas `app.js`.

>**Tugas**: tuliskan perintah untuk mengecek validitas berkas `app.js` di dalam berkas `answer.txt`.

**Catatan:**
- Berkas `app-invalid.js` dapat Anda gunakan jika Anda butuh untuk mengecek sintaks yang tidak valid.
- Jangan hapus berkas apa pun yang ada di dalam folder ini.
- Jangan ubah kode di dalam berkas apa pun kecuali answer.txt.
