# Instruksi: 01-2-change-callstack
Di folder 01-2-change-callstack, terdapat berkas `app.js`.

>**Tugas**: Anda adalah tuliskan perintah untuk untuk menjalankan `app.js` dengan limit stack trace sebanyak 20. Tulis jawaban Anda di dalam berkas `answer.txt`.

**Catatan:**
- Jangan hapus berkas apa pun yang ada di dalam folder ini.
- Jangan ubah kode di dalam berkas apa pun kecuali answer.txt.
