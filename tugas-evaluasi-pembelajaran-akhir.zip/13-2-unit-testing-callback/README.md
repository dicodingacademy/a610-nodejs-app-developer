# 13-2-unit-testing-callback
> **Tugas**: Buatlah unit testing untuk menguji fungsi `generateRandomString` yang ada di berkas `utils.js`.
Dengan ketentuan sebagai berikut:
1. Pastikan Anda menguji skenario negatif dan skenario positif yang ada di fungsi `generateRandomString`.
2. Pastikan Anda mengonfigurasi berkas `package.json` agar dapat menjalankan testing dengan perintah `npm test`.

**Catatan:**
- Anda boleh menggunakan testing tools apa pun untuk menyelesaikan tantangan ini.
- Jika Anda menggunakan package pihak ketiga, jangan lupa untuk menghapus folder `node_modules` sebelum mengirimkan pekerjaan Anda.
