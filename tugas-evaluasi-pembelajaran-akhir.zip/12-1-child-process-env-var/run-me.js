const { MY_ENV_VAR } = process.env;
console.log(`MY_ENV_VAR: ${MY_ENV_VAR}`);
