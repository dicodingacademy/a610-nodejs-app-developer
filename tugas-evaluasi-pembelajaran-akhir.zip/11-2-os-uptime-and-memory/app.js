setTimeout(() => {
  console.log(null); // @TODO cetak uptime dari process
  console.log(null); // @TODO cetak uptime dari sistem operasi
  console.log(null); // @TODO cetak total memori yang tersedia di sistem operasi
  console.log(null); // @TODO cetak total heap memori
}, 1000);
